/* ============================================================
   data.js — All idea word banks organized by category
   Each category has: adjectives, nouns, actions
   These 3 parts are combined to make a full idea sentence.
   ============================================================ */

const IDEAS = {

  startup: {
    adjectives: [
      "AI-powered", "Sustainable", "Hyper-local", "Decentralized",
      "Subscription-based", "On-demand", "Social", "Automated",
      "Peer-to-peer", "Smart"
    ],
    nouns: [
      "Marketplace", "Platform", "Network", "Assistant",
      "Community", "Hub", "Service", "Dashboard", "Ecosystem", "Tool"
    ],
    actions: [
      "for Remote Workers", "for Pet Owners", "for Freelancers",
      "for Students", "for Small Businesses", "for Senior Citizens",
      "for Travelers", "for Artists", "for Gamers", "for Foodies"
    ]
  },

  app: {
    adjectives: [
      "Minimalist", "Gamified", "Real-time", "Offline-first",
      "Voice-powered", "Collaborative", "Mood-based", "Smart",
      "Privacy-focused", "Dark-mode"
    ],
    nouns: [
      "Habit Tracker", "Journal", "Budget Manager", "Recipe Finder",
      "Sleep Analyzer", "Focus Timer", "Language Tutor", "Friend Finder",
      "Mood Board", "Skill Tracker"
    ],
    actions: [
      "with AI insights", "with social features", "for teams",
      "with daily challenges", "that learns your patterns",
      "with beautiful charts", "with reminders", "for families",
      "with streaks", "synced across devices"
    ]
  },

  movie: {
    adjectives: [
      "Post-apocalyptic", "Psychological", "Romantic", "Sci-fi",
      "Animated", "Noir", "Supernatural", "Dark-comedy",
      "Historical", "Cyberpunk"
    ],
    nouns: [
      "Thriller", "Drama", "Adventure", "Mystery", "Heist",
      "Love Story", "Survival Story", "Comedy", "Biopic", "Road Trip"
    ],
    actions: [
      "set in space", "set in ancient India", "told in reverse",
      "from the villain's perspective", "involving time travel",
      "during a pandemic", "inside a video game",
      "with an unreliable narrator", "set in 2050", "based on true events"
    ]
  },

  game: {
    adjectives: [
      "Procedurally-generated", "Multiplayer", "Pixel-art", "Open-world",
      "Rogue-like", "Narrative-driven", "Physics-based", "Horror",
      "Cozy", "Competitive"
    ],
    nouns: [
      "Dungeon Crawler", "City Builder", "Puzzle Game", "Platformer",
      "Strategy Game", "Simulation", "Tower Defense", "Card Game",
      "Racing Game", "Sandbox"
    ],
    actions: [
      "where you play as a villain", "with permadeath", "on the moon",
      "inside a dream", "that teaches coding", "controlled by your voice",
      "with no combat", "that changes daily",
      "where NPCs remember you", "set underwater"
    ]
  },

  random: {
    adjectives: [
      "Weird", "Brilliant", "Unexpected", "Controversial",
      "Simple yet", "Futuristic", "Retro", "Underground",
      "Viral", "Niche"
    ],
    nouns: [
      "Invention", "Business Idea", "Side Project", "Social Experiment",
      "Creative Concept", "Life Hack", "Community Project",
      "Micro SaaS", "Art Installation", "Bot"
    ],
    actions: [
      "nobody has tried yet", "that solves a tiny problem",
      "for the internet era", "you can build in a weekend",
      "with 10,000 potential users", "that would go viral",
      "worth millions", "only you could build",
      "that changes one habit", "the world actually needs"
    ]
  }

};
