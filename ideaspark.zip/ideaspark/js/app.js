/* ============================================================
   app.js — Main JavaScript logic for IdeaSpark
   Handles: idea generation, history, clipboard, UI updates
   ============================================================ */


// ============================================================
// STATE — Variables that track the app's current status
// ============================================================
let currentCategory = "startup";  // which category is selected
let generateCount   = 0;          // how many ideas have been generated
let history         = [];         // array storing past ideas


// ============================================================
// UTILITY — Helper functions used throughout the app
// ============================================================

/**
 * Returns a random element from any array.
 * Uses Math.random() * array.length to get a random index.
 * @param {Array} arr - Any array to pick from
 * @returns {*} A random element
 */
function getRandom(arr) {
  const randomIndex = Math.floor(Math.random() * arr.length);
  return arr[randomIndex];
}

/**
 * Returns a random category key (excluding "random" itself).
 * Used when user selects the "Surprise" category.
 * @returns {string} A category key like "startup", "app", etc.
 */
function getRandomCategory() {
  const cats = ["startup", "app", "movie", "game"];
  return getRandom(cats);
}


// ============================================================
// CORE — Main idea generation function
// ============================================================

/**
 * Generates a new idea by:
 * 1. Picking a category
 * 2. Randomly selecting one word from each array (adj, noun, action)
 * 3. Combining them into a sentence
 * 4. Updating the UI and history
 */
function generateIdea() {

  // --- Step 1: Disable button briefly to prevent spam clicks ---
  const btn = document.getElementById("generateBtn");
  btn.disabled = true;
  setTimeout(() => btn.disabled = false, 600);

  // --- Step 2: Determine the active category ---
  const cat  = currentCategory === "random" ? getRandomCategory() : currentCategory;
  const data = IDEAS[cat]; // grab the word arrays for this category

  // --- Step 3: Pick one random word from each array ---
  const adj    = getRandom(data.adjectives);
  const noun   = getRandom(data.nouns);
  const action = getRandom(data.actions);

  // --- Step 4: Combine into one full idea string ---
  const ideaText = `${adj} ${noun} ${action}`;

  // --- Step 5: Update the counter ---
  generateCount++;
  document.getElementById("totalGenerated").textContent = generateCount;
  document.getElementById("ideaNumber").textContent = `#${String(generateCount).padStart(3, "0")}`;

  // --- Step 6: Update the category tag label ---
  const tagMap = {
    startup: "🚀 STARTUP",
    app:     "📱 APP IDEA",
    movie:   "🎬 MOVIE",
    game:    "🎮 GAME",
    random:  "🎲 RANDOM"
  };
  document.getElementById("ideaTag").textContent = tagMap[cat] || cat.toUpperCase();

  // --- Step 7: Animate the idea text (fade out → update → fade in) ---
  const ideaEl = document.getElementById("ideaText");
  ideaEl.classList.remove("show");

  setTimeout(() => {
    ideaEl.textContent = ideaText;
    ideaEl.classList.add("show");
  }, 100);

  // --- Step 8: Render word-type pills (adjective / noun / action) ---
  renderPills(adj, noun, action);

  // --- Step 9: Animate the card's top color border ---
  const card = document.getElementById("ideaCard");
  card.classList.remove("revealed");
  setTimeout(() => card.classList.add("revealed"), 50);

  // --- Step 10: Save to history ---
  addToHistory(ideaText, cat);
}


// ============================================================
// PILLS — Show labels below the idea (adjective / noun / action)
// ============================================================

/**
 * Creates and animates the three word-type pill labels.
 * Each pill is staggered using setTimeout for a smooth effect.
 */
function renderPills(adj, noun, action) {
  const pillsContainer = document.getElementById("wordPills");
  pillsContainer.innerHTML = ""; // clear old pills

  const pills = [
    { word: adj,    type: "adj",  label: "adjective" },
    { word: noun,   type: "noun", label: "noun"      },
    { word: action, type: "verb", label: "action"    }
  ];

  pills.forEach((p, index) => {
    const pill = document.createElement("div");
    pill.className = `pill ${p.type}`;
    pill.textContent = p.label;
    pill.title = p.word; // shows word on hover

    pillsContainer.appendChild(pill);

    // Stagger the animation: each pill appears 100ms after the previous
    setTimeout(() => pill.classList.add("show"), 200 + index * 100);
  });
}


// ============================================================
// HISTORY — Store and display previously generated ideas
// ============================================================

/**
 * Adds a new idea to the beginning of the history array,
 * keeps max 10 items, then re-renders the history list.
 */
function addToHistory(idea, cat) {
  history.unshift({ idea, cat });        // add to front of array
  if (history.length > 10) history.pop(); // remove oldest if over 10
  renderHistory();
}

/**
 * Rebuilds the history list in the DOM from the history array.
 * Also shows/hides the history section based on whether items exist.
 */
function renderHistory() {
  const section = document.getElementById("historySection");
  const list    = document.getElementById("historyList");

  // Show section only when there's at least 1 item
  section.style.display = history.length > 0 ? "block" : "none";

  list.innerHTML = ""; // clear old items

  history.forEach((item) => {
    const div = document.createElement("div");
    div.className = "history-item";
    div.innerHTML = `<span>${item.idea}</span><span class="history-cat">${item.cat}</span>`;

    // Clicking a history item loads it back into the main card
    div.addEventListener("click", () => {
      const ideaEl = document.getElementById("ideaText");
      ideaEl.classList.remove("show");
      setTimeout(() => {
        ideaEl.textContent = item.idea;
        ideaEl.classList.add("show");
      }, 100);
    });

    list.appendChild(div);
  });

  // Update the "Saved" counter
  document.getElementById("totalSaved").textContent = history.length;
}

/**
 * Clears all history and resets the counter.
 */
function clearHistory() {
  history = [];
  renderHistory();
  document.getElementById("totalSaved").textContent = 0;
}


// ============================================================
// CLIPBOARD — Copy idea text to user's clipboard
// ============================================================

/**
 * Copies the currently displayed idea to clipboard.
 * Uses the modern Clipboard API with a fallback for older browsers.
 */
function copyIdea() {
  const text = document.getElementById("ideaText").textContent;

  // Don't copy the placeholder text
  if (text === "Your next big idea is one click away") return;

  // Modern Clipboard API (works in Chrome, Firefox, Edge)
  navigator.clipboard.writeText(text)
    .then(() => showToast())
    .catch(() => {
      // Fallback for older browsers using deprecated execCommand
      const el = document.createElement("textarea");
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      showToast();
    });
}

/**
 * Shows a "COPIED!" toast notification for 2 seconds.
 */
function showToast() {
  const toast = document.getElementById("copyToast");
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2000);
}


// ============================================================
// EVENT LISTENERS — Wiring up user interactions
// ============================================================

/**
 * Category button clicks use EVENT DELEGATION:
 * Instead of adding a listener to each button,
 * we add ONE listener to the parent and check what was clicked.
 * This is more efficient and works for dynamically added elements too.
 */
document.getElementById("categoryBtns").addEventListener("click", (e) => {
  const btn = e.target.closest(".cat-btn");
  if (!btn) return; // ignore clicks outside buttons

  // Remove "active" class from all buttons
  document.querySelectorAll(".cat-btn").forEach(b => b.classList.remove("active"));

  // Add "active" to the clicked button
  btn.classList.add("active");

  // Update our state variable
  currentCategory = btn.dataset.cat;
});

/**
 * Keyboard shortcut: Press SPACEBAR to generate a new idea.
 * Only triggers when the body itself is focused (not inside an input).
 */
document.addEventListener("keydown", (e) => {
  if (e.code === "Space" && e.target === document.body) {
    e.preventDefault(); // prevent page scroll
    generateIdea();
  }
});
